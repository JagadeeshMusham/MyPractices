package rest_client;

import java.util.Scanner;

import org.apache.spark.sql.SparkSession;

import rest_client.dto.CRUDOperations;

/**
 * @author Centina
 *
 */
public class App {
	public static void main(String[] args) {
		System.out.println("===========>\tTest123_Spark initiating...");

		// Spark initialization
		SparkSession spark = new SparkSession.Builder().appName("Spark ES test")
//				.master("spark://172.31.7.29:7077") // 7.42
				// Un comment this to use master running in local
				.master("local").getOrCreate();

//		SparkConf conf = new SparkConf().setAppName(appName).setMaster(master);
//		JavaSparkContext sc = new JavaSparkContext(conf);
//		
//		List<Integer> data = Arrays.asList(1, 2, 3, 4, 5);
//		JavaRDD<Integer> distData = sc.parallelize(data);

		System.out.println("Spark started...");

		// creating an Object to perform the CRUD operations on Elastic search
		CRUDOperations crudOperations = new CRUDOperations();

		// create a rest high level client
		crudOperations.makeRestHighLevelClient();

		// Scanner to take inputs from the console
		Scanner scanner = new Scanner(System.in);

		// The status to continue the while loop
		boolean bContinue = true;

		while (bContinue) {
			// Various inputs from the user, This seems to be like Menu driven approach
			System.out.println("\n\n\n\n");
			System.out.println("1. Insert Person");
			System.out.println("2. Edit Person");
			System.out.println("3. Get Person");
			System.out.println("4. Delete Person");
			System.out.println("5. Exit");
			System.out.println("Please select a option from above:");

			int option = scanner.nextInt();
			try {
				switch (option) {
				case 1:
					// Insert person
					System.out.print("Enter a person name:");
					String personName = scanner.next();
					System.out.print("\nEnter city of the person: " + personName);
					String city = scanner.next();

					System.out.println("\nInserting a person with name " + personName);
					crudOperations.insertPerson(personName, city);

					break;

				case 2:
					// Edit person
					System.out.print("Enter a person ID to change:");
					String person = scanner.next();

					System.out.print("Enter field name to change for id " + person + " : ");
					String fieldName = scanner.next();

					System.out.print("Enter new field value for id " + person + " : ");
					String fieldValue = scanner.next();

					crudOperations.updatePersonById(person, fieldName, fieldValue);
					break;

				case 3:
					// Get person by ID or name
					System.out.println("1. Get Person by ID");
					System.out.println("2. Get Person by name");
					System.out.println("3. Get Person by name");
					System.out.println("Select an option to get Person:");

					int getOption = scanner.nextInt();

					switch (getOption) {
					case 1:
						// get persons by id
						System.out.print("Enter a person ID to get details:");
						person = scanner.next();
						crudOperations.displayPerson(person, true);
						break;
					case 2:
						// get persons by name
						System.out.print("Enter a person name to get details:");
						person = scanner.next();
						crudOperations.displayPerson(person, false);
						break;
					case 3:
						// Get all persons
						crudOperations.displayAllPersons();
						break;
					default:
						System.out.println("Selected option is Invalid");
					}

					break;

				case 4:
					// Delete person
					System.out.println("1. Delete person by ID");
					System.out.println("2. Delete person by name");
					System.out.println("Select any one delete option from above:");

					int deleteOption = scanner.nextInt();

					if (deleteOption == 1) {
						System.out.print("Enter a person ID to delete:");
						person = scanner.next();
						crudOperations.deletePerson(person, true);
					} else {
						System.out.print("Enter a person name to delete:");
						person = scanner.next();
						crudOperations.deletePerson(person, false);
					}

					break;

				case 5:
					// Exit
					bContinue = false;
					break;

				default:
					System.out.println("Please select valid option from provided list.");
				}
			} catch (Exception e) {
				System.out.println("Caught exception: " + e.getMessage());
				e.printStackTrace();
			}
		}

		scanner.close();
		crudOperations.closeConnection();
	}

}
