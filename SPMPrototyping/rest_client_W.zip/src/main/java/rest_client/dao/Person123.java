package rest_client.dao;

public class Person123 {
    private String personId;
    private String name;
    private String city;

	public void setPersonID(String string) {
        this.personId = string;
    }

    public String getPersonId() {
        return personId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "Person [personId=" + personId + ", name=" + name + ", city=" + city + "]";
	}

//    public void setPersonId(String toString) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }

}
