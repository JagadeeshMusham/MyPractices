package rest_client.dto;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.http.HttpHost;
import org.elasticsearch.ElasticsearchException;
import org.elasticsearch.ElasticsearchParseException;
import org.elasticsearch.action.DocWriteResponse;
import org.elasticsearch.action.delete.DeleteRequest;
import org.elasticsearch.action.delete.DeleteResponse;
import org.elasticsearch.action.get.GetRequest;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.action.update.UpdateResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.TermQueryBuilder;
import org.elasticsearch.index.reindex.BulkByScrollResponse;
import org.elasticsearch.index.reindex.DeleteByQueryRequest;
import org.elasticsearch.rest.RestStatus;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.builder.SearchSourceBuilder;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

//import rest_client.dao.Person;

/**
 * @author Centina
 *
 */
/**
 * @author Centina
 *
 */
/**
 * @author Centina
 *
 */
/**
 * @author Centina
 *
 */
public class CRUDOperations {

	// The config parameters for the connection
	private final String HOST = "localhost";
	private final int PORT_ONE = 9200;
	private final int PORT_TWO = 9300;
	private final String SCHEME = "http";

	/**
	 * This is used to convert object to JSON and vice versa
	 */
	private ObjectMapper objectMapper = new ObjectMapper();

	// Index to operate
	private final String INDEX = "persondata";

	// Map to perform CRUD operations
	private final String TYPE = "person";

	// rest client which is used to connect to elasticsearch
	private RestHighLevelClient restHighLevelClient;

	/**
	 * Initiate rest client
	 * 
	 * @return rest client
	 */
	public synchronized RestHighLevelClient makeRestHighLevelClient() {
		System.out.println("===========>\tTest123_makeRestHighLevelClient started");
		if (restHighLevelClient == null) {
			restHighLevelClient = new RestHighLevelClient(
					RestClient.builder(new HttpHost(HOST, PORT_ONE, SCHEME), new HttpHost(HOST, PORT_TWO, SCHEME)));
		}

		System.out.println("===========>\tTest123_makeRestHighLevelClient ended");

		return restHighLevelClient;
	}

	/**
	 * This method inserts Person into given map and index
	 * 
	 * @param personName The person name
	 * @param city       The city of the person
	 * 
	 * @return returns the boolean value based on the state of the insert operation
	 */
	public boolean insertPerson(String personName, String city) {
		Person person = new Person();
		person.setName(personName);

		// Construct the person
		person.setPersonId(UUID.randomUUID().toString());
		Map<String, Object> dataMap = new HashMap<String, Object>();
		dataMap.put("personId", person.getPersonId());
		dataMap.put("name", person.getName());
		dataMap.put("city", city);
		IndexRequest indexRequest = new IndexRequest(INDEX, TYPE).source(dataMap);

		try {
			// insert the person to INDEX and TYPE
			IndexResponse indResponse = restHighLevelClient.index(indexRequest, RequestOptions.DEFAULT);
			if (indResponse.status() == RestStatus.OK || indResponse.status() == RestStatus.CREATED) {
				System.out.println("Person created successfully with name:" + person.getName());
				return true;
			}
		} catch (ElasticsearchException e) {
			e.getDetailedMessage();
		} catch (Exception ex) {
			System.out.println(ex.getLocalizedMessage());
		}

		System.out.println("Person creation failed with name:" + person.getName());
		return false;
	}

	/**
	 * Based on the ID this method will return the Person
	 * 
	 * @param personId, The person ID
	 * 
	 * @return returns the person object
	 */
	private Person getPersonById(String personId) {
		System.out.println("Getting person with Id: " + personId);

		// Get the person based on the ID
		GetRequest getPersonRequest = new GetRequest(INDEX, TYPE, personId);
		GetResponse getResponse = null;
		try {
			getResponse = restHighLevelClient.get(getPersonRequest, RequestOptions.DEFAULT);
		} catch (java.io.IOException e) {
			e.getLocalizedMessage();
		}

		Person person = null;
		if (getResponse != null) {
			// convert JSON into Person object
			person = objectMapper.convertValue(getResponse.getSourceAsMap(), Person.class);
		} else {
			person = null;
		}

		return person;
	}

	/**
	 * Get Person by name
	 * 
	 * @param personName, The person name
	 * 
	 * @return returns the person object
	 * 
	 * @throws IOException
	 */
	private List<Person> getPersonsByName(String personName) {
		SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
		searchSourceBuilder.query(QueryBuilders.matchQuery("name", personName));

		SearchRequest searchRequest = new SearchRequest(INDEX);
		searchRequest.source(searchSourceBuilder);

		// search person by name
		SearchResponse searchResponse;
		List<Person> persons = new ArrayList<Person>();

		try {
			// executing the search
			searchResponse = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);

			SearchHits searchHits = searchResponse.getHits();
			List<SearchHit> hitList = Arrays.asList(searchHits.getHits());

			// process the hit list
			for (SearchHit hit : hitList) {
				ObjectMapper mapper = new ObjectMapper();
				persons.add(mapper.readValue(hit.getSourceAsString(), Person.class));
			}
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return persons;
	}

	/**
	 * Update person by ID
	 * 
	 * @param id,         The person ID
	 * @param fieldName,  Field name to update
	 * @param fieldValue, field value to update
	 * 
	 * @return returns the status of the operation
	 */
	public boolean updatePersonById(String id, String fieldName, String fieldValue) {

		// getting person by ID
		Person person = this.getPersonById(id);
		if (person == null) {
			System.out.println("Person not found with ID: " + id);
			return false;
		}

		StringBuilder logMessage = new StringBuilder();

		if ("name".compareTo(fieldName) == 0) {
			person.setName(fieldValue);
			logMessage.append("Changing name from ").append(person.getName()).append(" to ").append(fieldValue)
					.append("for personID: ").append(id);
		} else if ("city".compareTo(fieldName) == 0) {
			person.setCity(fieldValue);
			logMessage.append("Changing the city from ").append(person.getCity()).append(" to ").append(fieldValue)
					.append("for personID: ").append(id);
		} else {
			System.out.println("The given field '" + fieldName + "' not found");
			return false;
		}

		System.out.println(logMessage);

		// Fetch Object after its update
		try {
			UpdateRequest updateRequest = new UpdateRequest(INDEX, TYPE, id).fetchSource(true);

			String personJson = objectMapper.writeValueAsString(person);
			updateRequest.doc(personJson, XContentType.JSON);
			UpdateResponse updateResponse = restHighLevelClient.update(updateRequest, RequestOptions.DEFAULT);

			Map<String, Object> personMap = updateResponse.getGetResult().sourceAsMap();
			Person resPerson = objectMapper.convertValue(personMap, Person.class);

			if (resPerson != null) {
				System.out.println("Person changed successfully. " + resPerson.toString());
				return true;
			}

		} catch (JsonProcessingException e) {
			System.out.println(e.getLocalizedMessage());
		} catch (java.io.IOException e) {
			System.out.println(e.getLocalizedMessage());
		} catch (ElasticsearchParseException e) {
			System.out.println(e.getLocalizedMessage());
		} catch (Exception e) {
			System.out.println(e.getLocalizedMessage());
		}

		System.out.println("Unable to update person");
		return false;
	}

	/**
	 * Delete person by ID
	 * 
	 * @param id, person id
	 * 
	 * @return returns the status of operation
	 */
	public boolean deletePersonById(String id) {
		System.out.println("Deleting person with id: " + id);

		DeleteRequest deleteRequest = new DeleteRequest(INDEX, TYPE, id);
		try {
			DeleteResponse deleteResponse = restHighLevelClient.delete(deleteRequest, RequestOptions.DEFAULT);

			if (deleteResponse.getResult() == DocWriteResponse.Result.DELETED == true) {
				System.out.println("Deletion succesfull");
				return true;
			}

		} catch (java.io.IOException e) {
			e.getLocalizedMessage();
		}

		System.out.println("Deletion got failed");
		return false;
	}

	/**
	 * To delete list persons which matches to given name
	 * 
	 * @param personName, The person name
	 * 
	 * @return returns the status of the operation
	 * 
	 * @throws IOException
	 */
	private boolean deletePersonByName(String personName) throws IOException {
		DeleteByQueryRequest request = new DeleteByQueryRequest(INDEX);
		request.setConflicts("proceed");
		request.setQuery(new TermQueryBuilder("name", personName));

		// delete query to elastic-search
		BulkByScrollResponse bulkResponse = restHighLevelClient.deleteByQuery(request, RequestOptions.DEFAULT);
		if (bulkResponse != null) {
			long deletedDocs = bulkResponse.getDeleted();
			if (deletedDocs > 0) {
				System.out.println("The deleted document count is: " + deletedDocs);
				return true;
			}
		}

		return false;
	}

	/**
	 * delete person by name
	 * 
	 * @param person,      The person name or id
	 * @param bDeleteById, delete option
	 * 
	 * @return returns the status of the operation
	 */
	public boolean deletePerson(String person, boolean bDeleteById) {

		try {
			if (bDeleteById) {
				System.out.println("Deleting person by ID: " + person);
				return deletePersonById(person);
//				System.out.println("Deleting person by id: " + person);
//				deleteRequest = new DeleteRequest(INDEX, TYPE, person);
//
//				// delete request to elastic-search
//				DeleteResponse deleteResponse = restHighLevelClient.delete(deleteRequest, RequestOptions.DEFAULT);
//				if (deleteResponse.getResult() == DocWriteResponse.Result.DELETED == true) {
//					System.out.println("Deletion succesfull");
//					return true;
//				}
			} else {
				System.out.println("Deleting person by name: " + person);

				if (deletePersonByName(person)) {
					return true;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		System.out.println("Failed to delete the person: " + person);
		return false;
	}

	/**
	 * Retrieve the person by ID or name
	 * 
	 * @param personID, The person ID
	 * 
	 * @param bByID,    The display option
	 * 
	 * @return returns the status of the operation
	 */
	public boolean displayPerson(String personID, boolean bByID) {
		if (bByID) {
			Person person = this.getPersonById(personID);

			if (person == null) {
				System.out.println("Person details not found for person: " + personID);
				return false;
			}

			System.out.println("Person details: " + person.toString());
		} else {
			List<Person> persons = this.getPersonsByName(personID);

			if (persons == null || persons.size() < 1) {
				System.out.println("Person details not found for person: " + personID);
				return false;
			}

			for (Person person : persons) {
				System.out.println("Person details: " + person.toString());
			}
		}

		return true;
	}

	/**
	 * @throws IOException
	 */
	public void displayAllPersons() {

		SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
		searchSourceBuilder.query(QueryBuilders.matchAllQuery());

		// Prepare search request
		SearchRequest searchRequest = new SearchRequest(INDEX);
		searchRequest.source(searchSourceBuilder);

		try {
			// Search the Index and map
			SearchResponse searchResponse = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
			System.out.println(searchResponse);

			List<SearchHit> searchHits = Arrays.asList(searchResponse.getHits().getHits());
			List<Person> persons = new ArrayList<Person>();

			for (SearchHit hit : searchHits) {
				ObjectMapper mapper = new ObjectMapper();
				persons.add(mapper.readValue(hit.getSourceAsString(), Person.class));
			}

			for (Person person : persons) {
				System.out.println(person.toString());
			}

		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	/**
	 * Closing the high level rest client
	 */
	public synchronized void closeConnection() {
		try {

			// closing the rest high level client
			if (restHighLevelClient != null) {
				restHighLevelClient.close();
				restHighLevelClient = null;
			}

		} catch (IOException e) {
			System.out.println("Got exception while closing the restHighLevelClient" + e.toString());
		}
	}

}
