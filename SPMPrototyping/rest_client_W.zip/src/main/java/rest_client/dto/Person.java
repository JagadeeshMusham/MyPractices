package rest_client.dto;

/**
 * @author Centina
 *
 */
public class Person {

	/**
	 * The person ID
	 */
	private String personId;

	/**
	 * The person name
	 */
	private String name;

	/**
	 * The city of the person
	 */
	private String city;

	/**
	 * @return the personId
	 */
	public String getPersonId() {
		return personId;
	}

	/**
	 * @param personId the personId to set
	 */
	public void setPersonId(String personId) {
		this.personId = personId;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * The toString method to display field values
	 */
	@Override
	public String toString() {
		return "Person [" + (personId != null ? "personId=" + personId + ", " : "")
				+ (name != null ? "name=" + name + ", " : "") + (city != null ? "city=" + city : "") + "]";
	}

}
